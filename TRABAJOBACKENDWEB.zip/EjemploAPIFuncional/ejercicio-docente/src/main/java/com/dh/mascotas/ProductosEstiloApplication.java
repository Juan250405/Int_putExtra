package com.dh.mascotas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductosEstiloApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductosEstiloApplication.class, args);
    }

}
    